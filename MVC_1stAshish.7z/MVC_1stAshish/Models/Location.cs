﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_1stAshish.Models
{
    public class Location
    {
        public int ID { get; set; }
        public string PLACE { get; set; }
        public string DETAILS { get; set; }
    }
}
